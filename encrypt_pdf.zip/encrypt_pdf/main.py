from tkinter import *
from tkinter import filedialog
import pikepdf
import os
from PIL import Image, ImageTk
root=Tk()
root.geometry("566x400")
root.title("Encryption")
root.resizable(False,False)

image=ImageTk.PhotoImage(Image.open("back3.jpg"))
image_label=Label(root, image=image)
image_label.place(x=0,y=0)


def openfile():
    global file_path
    file_path=filedialog.askopenfilename(initialdir=os.getcwd(),title="select Pdf file",
                                         filetype=(('PDF File','*.pdf'),('all files','*.*')))
    l1_ent.insert(END,file_path)

def protect():
    mainfile = source.get()
    protectfile = target.get()
    code = password.get()

    # Ensure the mainfile is opened correctly
    try:
        old_pdf = pikepdf.Pdf.open(mainfile)
        no_extr = pikepdf.Permissions(extract=False)
        old_pdf.save(protectfile, encryption=pikepdf.Encryption(user=code, allow=no_extr))
        print("PDF protected successfully.")
    except Exception as e:
        print(f"Error: {e}")

def on_enter_pass(event):
    if l3_ent.get()=='password':
        l3_ent.delete(0,END)
def hide():
    openeye.config(file='closeye.png')  #here it simply change the openeye image to closeeye image   
    l3_ent.config(show='*')
    eye_btn.config(command=show)
def show():
    openeye.config(file='openeye.png')
    l3_ent.config(show='')
    eye_btn.config(command=hide)     

source=StringVar()
l1=Label(root,text="Source PDF File:",font=("Arial Black",10),bg="black",fg="red",bd=0)
l1.place(x=5,y=155)
l1_ent=Entry(root,textvariable=source,font=("Courier New",12),bd=0)
l1_ent.place(x=150,y=150,width=310,height=30)

search=Button(root,text="🔍",font=(12),bd=0,command=openfile)
search.place(x=465,y=150,width=50,height=30)

target=StringVar()
l2=Label(root,text="Target PDF File:",font=("Arial Black",10),bg="black",fg="red",bd=0)
l2.place(x=5,y=200)
l2_ent=Entry(root,textvariable=target,font=("Courier New",12),bd=0)
l2_ent.place(x=150,y=195,width=310,height=30)

password=StringVar()
l3=Label(root,text="Set Password:",font=("Arial Black",10),bg="black",fg="red",bd=0)
l3.place(x=5,y=250)
l3_ent=Entry(root,textvariable=password,font=("Courier New",12),bd=0)
l3_ent.place(x=150,y=245,width=310,height=30)
l3_ent.insert(0,"password")
l3_ent.bind('<FocusIn>',on_enter_pass)

openeye=PhotoImage(file='openeye.png')
eye_btn=Button(root,image=openeye,bd=0,bg="white",cursor='hand2',command=hide)
eye_btn.place(x=428,y=248)

l4=Label(root,text="👉🏿",font=(12),bg="black",fg="white")
l4.place(x=5,y=300,width=50,height=30)
set=Button(root,text="Protect PDF File",font=("Arial Black",12),command=protect)
set.place(x=60,y=300,width=180,height=30)

root.mainloop()